#!/usr/bin/env bash
set -euo pipefail
required=(settings.gradle.kts build.gradle.kts app/build.gradle.kts app/src/main/AndroidManifest.xml app/src/main/cpp/CMakeLists.txt app/src/main/cpp/cronache_whisper.cpp app/src/main/java/it/cronache/app/transcription/WhisperNative.kt app/src/main/java/it/cronache/app/transcription/WhisperProvider.kt .github/workflows/android.yml)
for f in "${required[@]}"; do test -s "$f" || { echo "MISSING $f"; exit 1; }; done
grep -q 'v1.7.6' .github/workflows/android.yml
grep -q 'externalNativeBuild' app/build.gradle.kts
grep -q 'WhisperProvider' app/src/main/java/it/cronache/app/transcription/TranscriptionWorker.kt
echo 'Cronache structural verification: OK'
