package it.cronache.app.transcription
data class TranscriptSegment(val startMs:Long,val endMs:Long,val text:String,val confidence:Float)
data class TranscriptionContext(val subject:String="",val chapter:String="",val glossary:Set<String> = emptySet())
data class TranscriptionResult(val segments:List<TranscriptSegment>,val engine:String)
interface TranscriptionProvider{suspend fun transcribe(audioUri:String,context:TranscriptionContext,accurate:Boolean=false):TranscriptionResult}
class QualityEngine{fun uncertain(r:TranscriptionResult)=r.segments.filter{it.confidence<.72f};fun score(r:TranscriptionResult)=if(r.segments.isEmpty())0 else(r.segments.map{it.confidence}.average()*100).toInt()}
