package it.cronache.app.data
class CronacheRepository(db:CronacheDatabase){val dao=db.dao()
 suspend fun create(t:NodeType,p:String?,n:String,title:String)=dao.upsertNode(NodeEntity(type=t,parentId=p,number=n,title=title))
 suspend fun rename(id:String,v:String)=dao.renameNode(id,v);suspend fun renumber(id:String,v:String)=dao.renumberNode(id,v)
 suspend fun move(id:String,p:String?)=dao.moveNode(id,p,System.currentTimeMillis())
 suspend fun trash(id:String){trashTree(id,System.currentTimeMillis())};private suspend fun trashTree(id:String,at:Long){dao.directChildren(id).forEach{trashTree(it.id,at)};dao.trashAssetsForNode(id,at);dao.trashNodeExact(id,at)}
 suspend fun restore(id:String){restoreTree(id)};private suspend fun restoreTree(id:String){dao.restoreNode(id);dao.restoreAssetsForNode(id);dao.directChildren(id).forEach{restoreTree(it.id)}}
 suspend fun deleteForever(id:String){dao.directChildren(id).forEach{deleteForever(it.id)};dao.deleteAssetsForNode(id);dao.deleteNode(id)}
}
