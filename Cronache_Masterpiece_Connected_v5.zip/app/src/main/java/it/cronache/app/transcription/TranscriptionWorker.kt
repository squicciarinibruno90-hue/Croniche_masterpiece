package it.cronache.app.transcription
import android.content.Context
import androidx.work.*
import it.cronache.app.CronacheApp
import it.cronache.app.data.*
import it.cronache.app.model.ModelManager
import java.io.File
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.*
class TranscriptionWorker(c:Context,p:WorkerParameters):CoroutineWorker(c,p){
 override suspend fun doWork():Result{val app=applicationContext as CronacheApp;val dao=app.repository.dao;val assetId=inputData.getString("asset")?:return Result.failure();val a=dao.asset(assetId)?:return Result.failure();val jobId=inputData.getString("job")?:return Result.failure();val job=dao.job(jobId)?:ProcessingJobEntity(id=jobId,assetId=assetId);dao.upsertJob(job.copy(state=JobState.RUNNING,progress=5,error=null));return try{val model=ModelManager(applicationContext).active()?:error("MODEL_MISSING: importa un modello whisper.cpp .bin/.gguf dalle Impostazioni");val audio=File(a.uri?:error("Audio mancante"));dao.upsertJob(job.copy(state=JobState.RUNNING,progress=15));val r=WhisperProvider(applicationContext).transcribe(assetId,audio,model);dao.upsertJob(job.copy(state=JobState.RUNNING,progress=85));r.segments.forEach{dao.upsertSegment(it)};dao.upsertAsset(AssetEntity(nodeId=a.nodeId,type=AssetType.TRANSCRIPT_RAW,title="Trascrizione · ${a.title}",text=r.text));dao.upsertJob(job.copy(state=JobState.DONE,progress=100));Result.success()}catch(t:Throwable){val missing=t.message?.startsWith("MODEL_MISSING")==true;dao.upsertJob(job.copy(state=if(missing)JobState.PAUSED else JobState.FAILED,error=t.message));if(missing)Result.failure() else Result.retry()}}
 companion object{fun enqueue(c:Context,asset:String){val job=ProcessingJobEntity(assetId=asset);val app=c.applicationContext as CronacheApp;CoroutineScope(Dispatchers.IO).launch{app.repository.dao.upsertJob(job);val req=OneTimeWorkRequestBuilder<TranscriptionWorker>().setInputData(workDataOf("asset" to asset,"job" to job.id)).setConstraints(Constraints.Builder().setRequiresStorageNotLow(true).build()).setBackoffCriteria(BackoffPolicy.EXPONENTIAL,30,TimeUnit.SECONDS).build();WorkManager.getInstance(c).enqueueUniqueWork("transcribe-$asset",ExistingWorkPolicy.KEEP,req)}}}
}
