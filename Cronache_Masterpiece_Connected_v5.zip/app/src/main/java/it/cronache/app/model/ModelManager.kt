package it.cronache.app.model
import android.content.Context
import android.net.Uri
import java.io.File
class ModelManager(private val context:Context){
 private val dir=File(context.filesDir,"models").apply{mkdirs()}
 fun installed():List<File> = dir.listFiles()?.filter{it.extension.lowercase() in setOf("bin","gguf") }?.sortedByDescending{it.lastModified()}?:emptyList()
 fun active():File?=installed().firstOrNull()
 fun import(uri:Uri,name:String="whisper-model.bin"):File{val safe=name.replace(Regex("[^A-Za-z0-9._-]"),"_");val out=File(dir,safe);context.contentResolver.openInputStream(uri).use{input->requireNotNull(input);out.outputStream().use{input.copyTo(it)}};require(out.length()>1_000_000){"Il file non sembra un modello Whisper valido"};return out}
 fun delete(file:File)=file.takeIf{it.parentFile==dir}?.delete()==true
}
