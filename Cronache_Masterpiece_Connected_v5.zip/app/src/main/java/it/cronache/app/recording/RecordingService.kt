package it.cronache.app.recording
import android.app.*
import android.content.*
import android.media.MediaRecorder
import android.os.*
import androidx.core.app.NotificationCompat
import it.cronache.app.CronacheApp
import it.cronache.app.data.*
import it.cronache.app.transcription.TranscriptionWorker
import kotlinx.coroutines.*
import java.io.File

class RecordingService:Service(){private var recorder:MediaRecorder?=null;private var out:File?=null;private var started=0L;private val scope=CoroutineScope(SupervisorJob()+Dispatchers.IO)
 override fun onBind(i:Intent?):IBinder?=null
 override fun onCreate(){super.onCreate();if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CH,"Registrazione",NotificationManager.IMPORTANCE_LOW))}
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{when(i?.action){START->start(i.getStringExtra("nodeId"),i.getStringExtra("title"));STOP->stopAndSave();MARK->mark(i.getStringExtra("kind")?:"NOTE")};return START_STICKY}
 private fun start(nodeId:String?,title:String?){if(recorder!=null||nodeId==null)return;out=File(filesDir,"recordings/${System.currentTimeMillis()}.m4a").apply{parentFile?.mkdirs()};recorder=if(Build.VERSION.SDK_INT>=31)MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder();recorder!!.apply{setAudioSource(MediaRecorder.AudioSource.MIC);setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);setAudioEncoder(MediaRecorder.AudioEncoder.AAC);setAudioEncodingBitRate(128000);setAudioSamplingRate(44100);setOutputFile(out!!.absolutePath);prepare();start()};started=System.currentTimeMillis();getSharedPreferences("recording",0).edit().putBoolean("active",true).putString("node",nodeId).putString("title",title?:"Lezione").putLong("started",started).apply();startForeground(73,notification("Registrazione attiva"))}
 private fun notification(s:String):Notification{
  fun pi(action:String,code:Int,kind:String?=null):PendingIntent{val i=Intent(this,RecordingService::class.java).setAction(action);if(kind!=null)i.putExtra("kind",kind);return PendingIntent.getService(this,code,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)}
  return NotificationCompat.Builder(this,CH).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("Cronache · registrazione").setContentText(s).setOngoing(true).setOnlyAlertOnce(true).addAction(android.R.drawable.ic_media_pause,"STOP",pi(STOP,1)).addAction(android.R.drawable.star_big_on,"IMPORTANTE",pi(MARK,2,"IMPORTANT")).addAction(android.R.drawable.ic_menu_help,"RIVEDI",pi(MARK,3,"REVIEW")).build()
 }
 private fun mark(kind:String){val p=getSharedPreferences("recording",0);val node=p.getString("node",null)?:return;p.edit().putString("pendingMarker",kind+":"+(System.currentTimeMillis()-started)).apply()}
 private fun stopAndSave(){val file=out;runCatching{recorder?.stop()};recorder?.release();recorder=null;val p=getSharedPreferences("recording",0);val node=p.getString("node",null);val title=p.getString("title","Lezione")?:"Lezione";p.edit().clear().apply();if(file!=null&&node!=null&&file.exists()){scope.launch{val dao=(application as CronacheApp).repository.dao;val a=AssetEntity(nodeId=node,type=AssetType.RECORDING,title=title,uri=file.absolutePath,durationMs=System.currentTimeMillis()-started);dao.upsertAsset(a);TranscriptionWorker.enqueue(applicationContext,a.id)}};stopForeground(STOP_FOREGROUND_REMOVE);stopSelf()}
 override fun onDestroy(){if(recorder!=null)stopAndSave();scope.cancel();super.onDestroy()}
 companion object{const val CH="recording";const val START="START";const val STOP="STOP";const val MARK="MARK"}
}
