package it.cronache.app.transcription
import android.content.Context
import it.cronache.app.data.TranscriptSegmentEntity
import org.json.JSONObject
import java.io.File
import kotlin.math.max
class WhisperProvider(private val context:Context){
 data class Result(val segments:List<TranscriptSegmentEntity>,val text:String)
 fun transcribe(assetId:String,audio:File,model:File,language:String="it"):Result{
  require(model.exists()){"Modello Whisper non installato"};require(WhisperNative.loadModel(model.absolutePath)){"Impossibile caricare il modello"};val pcm=AudioDecoder.decode16kMono(audio);val threads=max(2,Runtime.getRuntime().availableProcessors()-2);val json=JSONObject(WhisperNative.transcribe(pcm,language,threads,false));if(json.has("error"))error(json.getString("error"));val arr=json.getJSONArray("segments");val segs=buildList{for(i in 0 until arr.length()){val x=arr.getJSONObject(i);add(TranscriptSegmentEntity(assetId=assetId,startMs=x.getLong("start"),endMs=x.getLong("end"),text=x.getString("text").trim(),confidence=0.85f))}};return Result(segs,segs.joinToString(" "){it.text})
 }
}
