package it.cronache.app.data
import android.content.Context
import androidx.room.*
@Database(entities=[NodeEntity::class,AssetEntity::class,ProcessingJobEntity::class,MarkerEntity::class,GlossaryEntity::class,TranscriptSegmentEntity::class],version=2,exportSchema=false)
@TypeConverters(Converters::class) abstract class CronacheDatabase:RoomDatabase(){abstract fun dao():CronacheDao;companion object{fun create(c:Context)=Room.databaseBuilder(c,CronacheDatabase::class.java,"cronache.db").fallbackToDestructiveMigration().build()}}
