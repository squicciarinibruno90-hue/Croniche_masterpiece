package it.cronache.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import it.cronache.app.data.*
import it.cronache.app.model.ModelManager
import it.cronache.app.recording.RecordingService
import it.cronache.app.ui.CronacheTheme
import it.cronache.app.ui.MainViewModel

class MainActivity : ComponentActivity() {
    private var pendingRecording: (() -> Unit)? = null

    private val microphonePermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) pendingRecording?.invoke()
        pendingRecording = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CronacheTheme {
                CronacheRoot(
                    startRecording = { nodeId: String, title: String ->
                        startRecording(nodeId, title)
                    }
                )
            }
        }
    }

    private fun startRecording(nodeId: String, title: String) {
        val action: () -> Unit = {
            val intent = Intent(this, RecordingService::class.java)
                .setAction(RecordingService.START)
                .putExtra("nodeId", nodeId)
                .putExtra("title", title)
            ContextCompat.startForegroundService(this, intent)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            action()
        } else {
            pendingRecording = action
            microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
}

@Composable
fun CronacheRoot(
    startRecording: (String, String) -> Unit,
    vm: MainViewModel = viewModel()
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var openNodeId by rememberSaveable { mutableStateOf<String?>(null) }

    val tabs: List<Pair<String, ImageVector>> = listOf(
        "Home" to Icons.Default.Home,
        "Archivio" to Icons.Default.Folder,
        "Registra" to Icons.Default.Mic,
        "Studio" to Icons.Default.School,
        "Cerca" to Icons.Default.Search
    )

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index: Int, item: Pair<String, ImageVector> ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(item.second, contentDescription = item.first) },
                        label = { Text(item.first) }
                    )
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            when (selectedTab) {
                0 -> HomeScreen(
                    vm = vm,
                    onArchive = { selectedTab = 1 },
                    onRecord = { selectedTab = 2 }
                )
                1 -> {
                    val current = openNodeId
                    if (current == null) {
                        ArchiveScreen(vm = vm, onOpen = { id -> openNodeId = id })
                    } else {
                        NodeWorkspaceScreen(
                            id = current,
                            vm = vm,
                            onBack = { openNodeId = null },
                            onOpen = { id -> openNodeId = id },
                            startRecording = startRecording
                        )
                    }
                }
                2 -> RecorderScreen(vm = vm, startRecording = startRecording)
                3 -> StudyScreen(vm = vm)
                else -> SearchScreen(
                    vm = vm,
                    onNode = { id ->
                        openNodeId = id
                        selectedTab = 1
                    }
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(vm: MainViewModel, onArchive: () -> Unit, onRecord: () -> Unit) {
    val roots by vm.roots.collectAsState()
    val jobs by vm.jobs.collectAsState()
    val context = LocalContext.current
    var modelName by remember { mutableStateOf(ModelManager(context).active()?.name) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { ModelManager(context).import(uri, uri.lastPathSegment ?: "whisper-model.bin") }
                .onSuccess { modelName = it.name }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("CRONACHE", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Black)
            Text("Capture · Knowledge · Intelligence · Learning", color = MaterialTheme.colorScheme.secondary)
        }
        item {
            if (modelName == null) {
                Card(Modifier.fillMaxWidth().clickable { picker.launch(arrayOf("application/octet-stream", "*/*")) }) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Memory, contentDescription = null)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text("Installa modello Whisper", fontWeight = FontWeight.Bold)
                            Text("Importa un modello locale · nessuna API")
                        }
                    }
                }
            } else {
                Text("STT locale · $modelName ✓", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            }
        }
        item {
            Card(Modifier.fillMaxWidth().clickable(onClick = onRecord)) {
                Row(Modifier.padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text("Registra nuova lezione", fontWeight = FontWeight.Bold)
                        Text("Audio prioritario · elaborazione persistente")
                    }
                }
            }
        }
        if (jobs.any { it.state != JobState.DONE }) {
            item {
                Text("Coda elaborazioni", fontWeight = FontWeight.Bold)
                jobs.filter { it.state != JobState.DONE }.take(3).forEach { job ->
                    Text("${job.kind} · ${job.state} · ${job.progress}%", style = MaterialTheme.typography.bodySmall)
                    LinearProgressIndicator(progress = { job.progress / 100f }, modifier = Modifier.fillMaxWidth())
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Materie", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                TextButton(onClick = onArchive) { Text("ARCHIVIO") }
            }
        }
        items(roots.take(6), key = { it.id }) { node ->
            NodeCard(node = node, onClick = onArchive, onLongClick = {})
        }
        if (roots.isEmpty()) {
            item { Hint("Crea la prima materia nell'Archivio. Numero e titolo restano separati dall'identità interna.") }
        }
    }
}

@Composable
private fun ArchiveScreen(vm: MainViewModel, onOpen: (String) -> Unit) {
    val roots by vm.roots.collectAsState()
    val trash by vm.trash.collectAsState()
    var adding by remember { mutableStateOf(false) }
    var menuNode by remember { mutableStateOf<NodeEntity?>(null) }

    Column {
        TopBar("Archivio", Icons.Default.Add) { adding = true }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(roots, key = { it.id }) { node ->
                NodeCard(node, onClick = { onOpen(node.id) }, onLongClick = { menuNode = node })
            }
            if (trash.isNotEmpty()) item {
                Text("Cestino · ${trash.size} elementi", Modifier.padding(12.dp), color = MaterialTheme.colorScheme.secondary)
            }
        }
    }
    if (adding) {
        EditDialog("Nuova materia", "", "", onDismiss = { adding = false }) { number, title ->
            vm.create(NodeType.SUBJECT, null, number, title)
            adding = false
        }
    }
    menuNode?.let { node -> NodeActions(node, vm, onDismiss = { menuNode = null }) }
}

@Composable
private fun NodeWorkspaceScreen(
    id: String,
    vm: MainViewModel,
    onBack: () -> Unit,
    onOpen: (String) -> Unit,
    startRecording: (String, String) -> Unit
) {
    val children by vm.children(id).collectAsState(initial = emptyList())
    val assets by vm.assets(id).collectAsState(initial = emptyList())
    var adding by remember { mutableStateOf(false) }
    var menuNode by remember { mutableStateOf<NodeEntity?>(null) }

    Column {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Indietro") }
            Text("Workspace", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { adding = true }) { Icon(Icons.Default.Add, contentDescription = "Aggiungi") }
        }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                FilledTonalButton(
                    onClick = { startRecording(id, "Lezione ${System.currentTimeMillis()}") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Mic, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("REGISTRA QUI")
                }
            }
            items(children, key = { it.id }) { node ->
                NodeCard(node, onClick = { onOpen(node.id) }, onLongClick = { menuNode = node })
            }
            if (assets.isNotEmpty()) item {
                Text("Materiali e registrazioni", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
            }
            items(assets, key = { it.id }) { asset -> AssetCard(asset) }
            if (children.isEmpty() && assets.isEmpty()) item {
                Hint("Workspace vuoto. Crea un capitolo/modulo oppure registra direttamente qui.")
            }
        }
    }
    if (adding) {
        EditDialog("Nuovo contenuto", "", "", onDismiss = { adding = false }) { number, title ->
            vm.create(NodeType.CHAPTER, id, number, title)
            adding = false
        }
    }
    menuNode?.let { node -> NodeActions(node, vm, onDismiss = { menuNode = null }) }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NodeCard(node: NodeEntity, onClick: () -> Unit, onLongClick: () -> Unit) {
    val icon = when (node.type) {
        NodeType.SUBJECT -> Icons.Default.AutoStories
        NodeType.CHAPTER -> Icons.Default.Folder
        NodeType.MODULE -> Icons.Default.Article
    }
    Card(Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLongClick)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                if (node.number.isNotBlank()) Text(node.number, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Text(node.title, fontWeight = FontWeight.SemiBold)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null)
        }
    }
}

@Composable
private fun AssetCard(asset: AssetEntity) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (asset.type == AssetType.RECORDING) Icons.Default.GraphicEq else Icons.Default.Description, contentDescription = null)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(asset.title, fontWeight = FontWeight.SemiBold)
                Text(asset.type.name.replace('_', ' '), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
            }
            if (asset.type == AssetType.RECORDING) Icon(Icons.Default.PlayArrow, contentDescription = null)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NodeActions(node: NodeEntity, vm: MainViewModel, onDismiss: () -> Unit) {
    var editMode by remember { mutableIntStateOf(0) }
    if (editMode == 0) {
        ModalBottomSheet(onDismissRequest = onDismiss) {
            Text("${node.number} ${node.title}".trim(), Modifier.padding(20.dp), style = MaterialTheme.typography.titleLarge)
            ActionRow("Rinomina", Icons.Default.Edit) { editMode = 1 }
            ActionRow("Modifica numero", Icons.Default.Tag) { editMode = 2 }
            ActionRow("Sposta nel cestino", Icons.Default.Delete) { vm.trash(node.id); onDismiss() }
        }
    } else {
        EditDialog(
            title = if (editMode == 1) "Rinomina" else "Modifica numero",
            initialNumber = if (editMode == 2) node.number else "",
            initialTitle = if (editMode == 1) node.title else "",
            onDismiss = onDismiss
        ) { number, title ->
            if (editMode == 1) vm.rename(node.id, title) else vm.renumber(node.id, number)
            onDismiss()
        }
    }
}

@Composable
private fun RecorderScreen(vm: MainViewModel, startRecording: (String, String) -> Unit) {
    val roots by vm.roots.collectAsState()
    var chosen by remember { mutableStateOf<String?>(null) }
    var title by remember { mutableStateOf("Lezione") }
    Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("Registra", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
        Text("La registrazione ha priorità assoluta. La trascrizione viene accodata dopo lo stop.")
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Titolo registrazione") }, modifier = Modifier.fillMaxWidth())
        Text("Destinazione", fontWeight = FontWeight.Bold)
        roots.forEach { root ->
            FilterChip(selected = chosen == root.id, onClick = { chosen = root.id }, label = { Text(root.title) })
        }
        Button(
            onClick = { chosen?.let { nodeId -> startRecording(nodeId, title) } },
            enabled = chosen != null,
            modifier = Modifier.fillMaxWidth().height(58.dp)
        ) {
            Icon(Icons.Default.Mic, contentDescription = null)
            Spacer(Modifier.width(10.dp))
            Text("AVVIA REGISTRAZIONE")
        }
        Hint("Durante la registrazione puoi uscire dall'app: il foreground service continua a salvare l'audio sul dispositivo.")
    }
}

@Composable
private fun StudyScreen(vm: MainViewModel) {
    val jobs by vm.jobs.collectAsState()
    LazyColumn(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Studio", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
            Text("Strumenti costruiti sulle tue fonti, non su contenuti inventati.", color = MaterialTheme.colorScheme.secondary)
        }
        item { Feature("Ripasso intelligente", "Le trascrizioni completate alimenteranno gli strumenti di studio locali.", Icons.Default.Psychology) }
        item { Feature("Qualità prima dello studio", "${jobs.count { it.state == JobState.DONE }} completate · ${jobs.count { it.state == JobState.FAILED }} da controllare", Icons.Default.Verified) }
    }
}

@Composable
private fun SearchScreen(vm: MainViewModel, onNode: (String) -> Unit) {
    val state by vm.search.collectAsState()
    Column(Modifier.padding(18.dp)) {
        Text("Cerca", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
        OutlinedTextField(
            value = state.query,
            onValueChange = { query -> vm.find(query) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            placeholder = { Text("Titolo, numero, trascrizione…") },
            modifier = Modifier.fillMaxWidth()
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
            items(state.nodes, key = { it.id }) { node -> NodeCard(node, onClick = { onNode(node.id) }, onLongClick = {}) }
            items(state.assets, key = { it.id }) { asset -> AssetCard(asset) }
            if (state.query.isNotBlank() && state.nodes.isEmpty() && state.assets.isEmpty()) item { Hint("Nessun risultato.") }
        }
    }
}

@Composable
private fun Feature(title: String, body: String, icon: ImageVector) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp)) {
            Icon(icon, contentDescription = null)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(body, color = MaterialTheme.colorScheme.secondary)
            }
        }
    }
}

@Composable
private fun TopBar(title: String, icon: ImageVector, action: () -> Unit) {
    Row(Modifier.padding(20.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        IconButton(onClick = action) { Icon(icon, contentDescription = null) }
    }
}

@Composable
private fun Hint(text: String) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.large) {
        Text(text, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.secondary)
    }
}

@Composable
private fun ActionRow(title: String, icon: ImageVector, action: () -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        leadingContent = { Icon(icon, contentDescription = null) },
        modifier = Modifier.clickable(onClick = action)
    )
}

@Composable
private fun EditDialog(
    title: String,
    initialNumber: String,
    initialTitle: String,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var number by remember(initialNumber) { mutableStateOf(initialNumber) }
    var text by remember(initialTitle) { mutableStateOf(initialTitle) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = number, onValueChange = { number = it }, label = { Text("Numero") })
                OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("Titolo") })
            }
        },
        confirmButton = { Button(onClick = { onSave(number, text.ifBlank { "Senza titolo" }) }) { Text("SALVA") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ANNULLA") } }
    )
}
