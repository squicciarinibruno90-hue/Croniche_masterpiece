package it.cronache.app

import android.app.Application
import androidx.work.Configuration
import it.cronache.app.data.CronacheDatabase
import it.cronache.app.data.CronacheRepository

class CronacheApp : Application(), Configuration.Provider {
    lateinit var db: CronacheDatabase
    lateinit var repository: CronacheRepository
    override fun onCreate() {
        super.onCreate()
        db = CronacheDatabase.create(this)
        repository = CronacheRepository(db)
    }
    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder().setMinimumLoggingLevel(android.util.Log.INFO).build()
}
