package it.cronache.app.ui
import android.app.Application
import androidx.lifecycle.*
import it.cronache.app.CronacheApp
import it.cronache.app.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class SearchState(val query:String="",val nodes:List<NodeEntity> = emptyList(),val assets:List<AssetEntity> = emptyList())
class MainViewModel(app:Application):AndroidViewModel(app){private val repo=(app as CronacheApp).repository;private val dao=repo.dao
 val roots=dao.roots().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList());val jobs=dao.jobs().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList());val trash=dao.trash().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList());val search=MutableStateFlow(SearchState())
 fun children(id:String)=dao.children(id);fun assets(id:String)=dao.assets(id);fun markers(id:String)=dao.markers(id);fun segments(id:String)=dao.segments(id)
 fun create(t:NodeType,p:String?,n:String,title:String)=viewModelScope.launch{repo.create(t,p,n,title)};fun rename(id:String,v:String)=viewModelScope.launch{repo.rename(id,v)};fun renumber(id:String,v:String)=viewModelScope.launch{repo.renumber(id,v)};fun trash(id:String)=viewModelScope.launch{repo.trash(id)};fun restore(id:String)=viewModelScope.launch{repo.restore(id)};fun deleteForever(id:String)=viewModelScope.launch{repo.deleteForever(id)}
 fun find(q:String){viewModelScope.launch{search.value=if(q.isBlank())SearchState() else SearchState(q,dao.searchNodes(q),dao.searchAssets(q))}}
}
