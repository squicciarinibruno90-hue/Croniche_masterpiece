package it.cronache.app.data
import androidx.room.*
import java.util.UUID

enum class NodeType { SUBJECT, CHAPTER, MODULE }
enum class AssetType { RECORDING, TRANSCRIPT_RAW, TRANSCRIPT_CORRECTED, NOTE, PDF, IMAGE }
enum class JobState { QUEUED, RUNNING, PAUSED, DONE, FAILED }
@Entity(tableName="nodes", indices=[Index("parentId"),Index("deletedAt")])
data class NodeEntity(@PrimaryKey val id:String=UUID.randomUUID().toString(),val type:NodeType,val parentId:String?=null,val number:String="",val title:String,val sortOrder:Long=System.currentTimeMillis(),val createdAt:Long=System.currentTimeMillis(),val updatedAt:Long=System.currentTimeMillis(),val deletedAt:Long?=null)
@Entity(tableName="assets",indices=[Index("nodeId"),Index("deletedAt")])
data class AssetEntity(@PrimaryKey val id:String=UUID.randomUUID().toString(),val nodeId:String,val type:AssetType,val title:String,val uri:String?=null,val text:String?=null,val durationMs:Long=0,val createdAt:Long=System.currentTimeMillis(),val updatedAt:Long=System.currentTimeMillis(),val deletedAt:Long?=null)
@Entity(tableName="jobs",indices=[Index("assetId"),Index("state")])
data class ProcessingJobEntity(@PrimaryKey val id:String=UUID.randomUUID().toString(),val assetId:String,val kind:String="TRANSCRIBE",val state:JobState=JobState.QUEUED,val progress:Int=0,val checkpoint:Int=0,val error:String?=null,val createdAt:Long=System.currentTimeMillis(),val updatedAt:Long=System.currentTimeMillis())
@Entity(tableName="markers",indices=[Index("assetId")])
data class MarkerEntity(@PrimaryKey val id:String=UUID.randomUUID().toString(),val assetId:String,val atMs:Long,val kind:String,val label:String="")
@Entity(tableName="glossary",indices=[Index("scopeNodeId")])
data class GlossaryEntity(@PrimaryKey val id:String=UUID.randomUUID().toString(),val scopeNodeId:String?=null,val term:String,val aliases:String="",val weight:Int=1)
@Entity(tableName="transcript_segments",indices=[Index("assetId"),Index("startMs")])
data class TranscriptSegmentEntity(@PrimaryKey val id:String=UUID.randomUUID().toString(),val assetId:String,val startMs:Long,val endMs:Long,val text:String,val confidence:Float,val revisedText:String?=null)
class Converters{@TypeConverter fun nodeType(v:String)=NodeType.valueOf(v);@TypeConverter fun nodeType(v:NodeType)=v.name;@TypeConverter fun assetType(v:String)=AssetType.valueOf(v);@TypeConverter fun assetType(v:AssetType)=v.name;@TypeConverter fun jobState(v:String)=JobState.valueOf(v);@TypeConverter fun jobState(v:JobState)=v.name}
