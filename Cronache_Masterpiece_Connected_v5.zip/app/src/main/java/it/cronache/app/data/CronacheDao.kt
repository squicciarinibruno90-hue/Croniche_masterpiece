package it.cronache.app.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao interface CronacheDao{
 @Query("SELECT * FROM nodes WHERE parentId IS NULL AND deletedAt IS NULL ORDER BY sortOrder") fun roots():Flow<List<NodeEntity>>
 @Query("SELECT * FROM nodes WHERE parentId=:parent AND deletedAt IS NULL ORDER BY sortOrder") fun children(parent:String):Flow<List<NodeEntity>>
 @Query("SELECT * FROM nodes WHERE id=:id") suspend fun node(id:String):NodeEntity?
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertNode(v:NodeEntity)
 @Query("UPDATE nodes SET title=:v,updatedAt=:now WHERE id=:id") suspend fun renameNode(id:String,v:String,now:Long=System.currentTimeMillis())
 @Query("UPDATE nodes SET number=:v,updatedAt=:now WHERE id=:id") suspend fun renumberNode(id:String,v:String,now:Long=System.currentTimeMillis())
 @Query("UPDATE nodes SET parentId=:p,sortOrder=:o,updatedAt=:now WHERE id=:id") suspend fun moveNode(id:String,p:String?,o:Long,now:Long=System.currentTimeMillis())
 @Query("SELECT * FROM nodes WHERE parentId=:p") suspend fun directChildren(p:String):List<NodeEntity>
 @Query("UPDATE nodes SET deletedAt=:at WHERE id=:id") suspend fun trashNodeExact(id:String,at:Long)
 @Query("UPDATE assets SET deletedAt=:at WHERE nodeId=:id") suspend fun trashAssetsForNode(id:String,at:Long)
 @Query("UPDATE nodes SET deletedAt=NULL WHERE id=:id") suspend fun restoreNode(id:String)
 @Query("UPDATE assets SET deletedAt=NULL WHERE nodeId=:id") suspend fun restoreAssetsForNode(id:String)
 @Query("DELETE FROM nodes WHERE id=:id") suspend fun deleteNode(id:String)
 @Query("DELETE FROM assets WHERE nodeId=:id") suspend fun deleteAssetsForNode(id:String)
 @Query("SELECT * FROM nodes WHERE deletedAt IS NOT NULL ORDER BY deletedAt DESC") fun trash():Flow<List<NodeEntity>>
 @Query("SELECT * FROM assets WHERE nodeId=:id AND deletedAt IS NULL ORDER BY createdAt DESC") fun assets(id:String):Flow<List<AssetEntity>>
 @Query("SELECT * FROM assets WHERE id=:id") suspend fun asset(id:String):AssetEntity?
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAsset(v:AssetEntity)
 @Query("UPDATE assets SET title=:v,updatedAt=:now WHERE id=:id") suspend fun renameAsset(id:String,v:String,now:Long=System.currentTimeMillis())
 @Query("UPDATE assets SET deletedAt=:at WHERE id=:id") suspend fun trashAsset(id:String,at:Long=System.currentTimeMillis())
 @Query("SELECT * FROM jobs ORDER BY createdAt DESC") fun jobs():Flow<List<ProcessingJobEntity>>
 @Query("SELECT * FROM jobs WHERE id=:id") suspend fun job(id:String):ProcessingJobEntity?
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertJob(v:ProcessingJobEntity)
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun addMarker(v:MarkerEntity)
 @Query("SELECT * FROM markers WHERE assetId=:id ORDER BY atMs") fun markers(id:String):Flow<List<MarkerEntity>>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertSegment(v:TranscriptSegmentEntity)
 @Query("SELECT * FROM transcript_segments WHERE assetId=:id ORDER BY startMs") fun segments(id:String):Flow<List<TranscriptSegmentEntity>>
 @Query("SELECT * FROM nodes WHERE deletedAt IS NULL AND (title LIKE '%'||:q||'%' OR number LIKE '%'||:q||'%') LIMIT 100") suspend fun searchNodes(q:String):List<NodeEntity>
 @Query("SELECT * FROM assets WHERE deletedAt IS NULL AND (title LIKE '%'||:q||'%' OR text LIKE '%'||:q||'%') LIMIT 100") suspend fun searchAssets(q:String):List<AssetEntity>
}
