package it.cronache.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8FBF9F),
    secondary = Color(0xFFB7C9B8),
    background = Color(0xFF0B0F0D),
    surface = Color(0xFF111713),
    surfaceVariant = Color(0xFF1A231D),
    onPrimary = Color(0xFF07110B),
    onBackground = Color(0xFFE6EEE8),
    onSurface = Color(0xFFE6EEE8),
    error = Color(0xFFFFB4AB)
)

@Composable
fun CronacheTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        typography = Typography(),
        content = content
    )
}
