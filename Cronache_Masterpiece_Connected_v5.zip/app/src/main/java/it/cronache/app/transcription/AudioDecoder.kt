package it.cronache.app.transcription
import android.media.*
import java.io.File
import java.nio.ByteOrder
import kotlin.math.floor
object AudioDecoder {
 fun decode16kMono(file:File):FloatArray {
  val ex=MediaExtractor(); ex.setDataSource(file.absolutePath); var track=-1
  for(i in 0 until ex.trackCount) if(ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/")==true){track=i;break}
  require(track>=0){"Nessuna traccia audio"}; ex.selectTrack(track); val fmt=ex.getTrackFormat(track); val mime=fmt.getString(MediaFormat.KEY_MIME)!!; val rate=fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE); val channels=fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
  val codec=MediaCodec.createDecoderByType(mime); codec.configure(fmt,null,null,0); codec.start(); val raw=ArrayList<Float>(rate*60); val info=MediaCodec.BufferInfo(); var inputDone=false; var outputDone=false
  while(!outputDone){ if(!inputDone){val idx=codec.dequeueInputBuffer(10000);if(idx>=0){val b=codec.getInputBuffer(idx)!!;val sz=ex.readSampleData(b,0);if(sz<0){codec.queueInputBuffer(idx,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true}else{codec.queueInputBuffer(idx,0,sz,ex.sampleTime,0);ex.advance()}}}; val oi=codec.dequeueOutputBuffer(info,10000);if(oi>=0){val b=codec.getOutputBuffer(oi)!!;b.order(ByteOrder.LITTLE_ENDIAN);val shorts=b.asShortBuffer();val frames=shorts.remaining()/channels;repeat(frames){var sum=0f;repeat(channels){sum+=shorts.get()/32768f};raw.add(sum/channels)};outputDone=info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM!=0;codec.releaseOutputBuffer(oi,false)}}
  codec.stop();codec.release();ex.release(); if(rate==16000)return raw.toFloatArray(); val ratio=rate/16000.0; val out=FloatArray(floor(raw.size/ratio).toInt()); for(i in out.indices){val x=i*ratio;val a=x.toInt().coerceAtMost(raw.lastIndex);val z=(a+1).coerceAtMost(raw.lastIndex);val f=(x-a).toFloat();out[i]=raw[a]*(1-f)+raw[z]*f};return out
 }
}
