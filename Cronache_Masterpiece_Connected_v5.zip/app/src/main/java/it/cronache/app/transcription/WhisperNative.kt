package it.cronache.app.transcription
object WhisperNative {
    init { System.loadLibrary("cronache_whisper") }
    external fun loadModel(path:String):Boolean
    external fun unload()
    external fun transcribe(samples:FloatArray, language:String, threads:Int, translate:Boolean):String
}
