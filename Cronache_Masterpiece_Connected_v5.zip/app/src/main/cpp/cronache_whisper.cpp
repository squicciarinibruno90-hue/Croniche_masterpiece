#include <jni.h>
#include <android/log.h>
#include <whisper.h>
#include <string>
#include <vector>
#include <mutex>

static std::mutex g_mutex;
static whisper_context* g_ctx = nullptr;
static std::string g_model;
static void unload(){ if(g_ctx){ whisper_free(g_ctx); g_ctx=nullptr; g_model.clear(); } }
extern "C" JNIEXPORT jboolean JNICALL Java_it_cronache_app_transcription_WhisperNative_loadModel(JNIEnv* env,jobject,jstring path){
 std::lock_guard<std::mutex> lock(g_mutex); const char* p=env->GetStringUTFChars(path,nullptr); std::string next(p); env->ReleaseStringUTFChars(path,p);
 if(g_ctx && next==g_model) return JNI_TRUE; unload(); whisper_context_params cp=whisper_context_default_params(); g_ctx=whisper_init_from_file_with_params(next.c_str(),cp); if(g_ctx) g_model=next; return g_ctx?JNI_TRUE:JNI_FALSE;
}
extern "C" JNIEXPORT void JNICALL Java_it_cronache_app_transcription_WhisperNative_unload(JNIEnv*,jobject){ std::lock_guard<std::mutex> lock(g_mutex); unload(); }
extern "C" JNIEXPORT jstring JNICALL Java_it_cronache_app_transcription_WhisperNative_transcribe(JNIEnv* env,jobject,jfloatArray samples,jstring language,jint threads,jboolean translate){
 std::lock_guard<std::mutex> lock(g_mutex); if(!g_ctx) return env->NewStringUTF("{\"error\":\"model_not_loaded\"}");
 jsize n=env->GetArrayLength(samples); std::vector<float> pcm(n); env->GetFloatArrayRegion(samples,0,n,pcm.data());
 const char* lang=env->GetStringUTFChars(language,nullptr); auto params=whisper_full_default_params(WHISPER_SAMPLING_GREEDY); params.language=lang; params.translate=translate; params.n_threads=threads; params.print_progress=false; params.print_realtime=false; params.print_timestamps=false; params.no_context=false; params.single_segment=false;
 int rc=whisper_full(g_ctx,params,pcm.data(),(int)pcm.size()); env->ReleaseStringUTFChars(language,lang); if(rc!=0) return env->NewStringUTF("{\"error\":\"inference_failed\"}");
 std::string out="{\"segments\":["; int count=whisper_full_n_segments(g_ctx); for(int i=0;i<count;i++){ if(i)out+=","; auto esc=[](const char* s){std::string r;for(;*s;s++){if(*s=='\\'||*s=='\"')r+='\\';if(*s=='\n')r+="\\n";else r+=*s;}return r;}; out+="{\"start\":"+std::to_string(whisper_full_get_segment_t0(g_ctx,i)*10)+",\"end\":"+std::to_string(whisper_full_get_segment_t1(g_ctx,i)*10)+",\"text\":\""+esc(whisper_full_get_segment_text(g_ctx,i))+"\"}"; } out+="]}"; return env->NewStringUTF(out.c_str());
}
