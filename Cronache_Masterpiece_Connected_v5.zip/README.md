# Cronache 1.0 — local-first lecture intelligence for Android

Cronache records university lectures safely, stores a mutable UUID-based knowledge hierarchy, and transcribes recordings locally with whisper.cpp. No paid API or account is required.

## Build on GitHub
Upload the whole repository and run **Actions → Build Cronache APK → Run workflow**. The workflow installs Android NDK/CMake, vendors the pinned `whisper.cpp v1.7.6`, builds the native JNI bridge and uploads `Cronache-debug-apk`.

## First run
1. Create a subject and optionally chapters/modules.
2. On Home tap **Installa modello Whisper** and choose a whisper.cpp compatible `.bin`/`.gguf` model stored on the phone. Models are deliberately not committed to Git.
3. Record a lecture. Audio recording runs in a foreground microphone service and is saved before transcription is queued.
4. When stopped, WorkManager decodes M4A/AAC through Android MediaCodec to mono 16 kHz PCM, invokes whisper.cpp locally, stores timestamped segments and creates the raw transcript asset.

If no model is installed, the job becomes `PAUSED` with `MODEL_MISSING`; the recording remains safe.

## Product invariants
- Recording has higher priority than AI processing.
- Node identity is UUID-based; number/title can change without breaking references.
- Deletion is recursive-to-trash and restorable.
- Audio is source-of-truth; generated text is derived data.
- STT is offline and model files stay on device.

## Native dependency
`app/src/main/cpp/CMakeLists.txt` expects whisper.cpp in `app/src/main/cpp/whisper.cpp`. GitHub Actions clones the pinned release automatically. For local Android Studio builds, clone `ggerganov/whisper.cpp` tag `v1.7.6` into that directory first.
