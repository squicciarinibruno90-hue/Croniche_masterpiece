# Cronache architecture

`UI -> ViewModel -> Repository -> Room`

Recording is isolated in `RecordingService`; it writes audio first and only after stop creates an immutable recording asset and enqueues transcription. `TranscriptionWorker` is restartable WorkManager work. `TranscriptionProvider` is an interface so whisper.cpp, ONNX or another local engine never contaminates UI/domain code.

## Identity
A node UUID is permanent. `number`, `title`, `parentId` and `sortOrder` are mutable metadata. Renaming or renumbering therefore cannot invalidate assets or references.

## STT target pipeline
Audio master -> audio analysis -> VAD -> adaptive segments -> fast pass -> quality map -> selective accurate pass -> consensus -> constrained correction -> forced alignment -> semantic structure -> index.

The database already separates assets, transcript segments, jobs, markers and glossary so these stages can checkpoint independently.

## Resource policy
RECORDING=critical; first-pass STT=high; selective second pass=normal; cleanup=low; semantic indexing=idle. Never run heavy inference in the microphone service.
